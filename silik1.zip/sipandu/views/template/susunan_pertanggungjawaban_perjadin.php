<style type="text/css">
	.susunan_perjadin td, .susunan_perjadin li { vertical-align:top; font-size:13px; font-family: 'tahoma'; line-height: normal;}
</style>

<table width="100%" cellpadding="0" cellspacing="0" class="susunan_perjadin">
	<tr>
		<td><h4>SUSUNAN PERTANGGUNGJAWABAN PERJALANAN DINAS</h4></td>
	</tr>
</table>

<ol class="susunan_perjadin">
	<li>Surat Perjalanan Dinas (SPD) - Lembar 1</li>
	<li>Surat Perjalanan Dinas (SPD) - Lembar 2 (yang ada cap) Dari Silik</li>
	<li>Surat Perjalanan Dinas (SPD) - Lembar 2 (yang ada cap) Asli dari Lapangan</li>
	<li>Rincian Biaya Perjalanan Dinas</li>
	<li>Daftar Pengeluaran Riil (Jika Ada - Otomatis dari Silik)</li>
	<li>Tiket Pesawat, Boardingpass, Bill hotel, Tiket boat, Nota Bensin (Jika Ada dan Dipastikan Keabsahanya) ditempel dikertas A4 dan Difotocopy.</li>
	<!--<li>Surat Tugas</li>-->
	<li>Laporan Perjalanan Dinas</li>
</ol>

<table class="susunan_perjadin">
	<tr>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td><h4 style="color: red;">PERHATIAN!!</h4></td>
	</tr>
</table>
<ul class="susunan_perjadin">
	<li>Perjalanan Dinas akan dibayarkan apabila sudah mengumpulkan pertanggungjawaban.</li>
	<li>Mohon untuk <strong>melengkapi dan menyusun</strong> pertanggungjawaban perjalanan dinas sesuai dengan urutan diatas.</li>
	<li>Keabsahan atas bukti pertanggungjawaban perjalanan dinas merupakan tanggungjawab dari pelaksana perjalanan dinas.</li>
	<li>Pastikan bpk/ibu sudah menandatangani bagian/tempat tanda tangan yang ada nama bpk/ibu sebelum dikumpulkan.</li>
	<li>Pertanggungjawaban perjalanan dinas paling <strong>lambat</strong> dikumpulkan pada hari <strong>Rabu jam 15.00 wita</strong> untuk pembayaran yang akan dibayarkan pada hari Jumat di Minggu yang sama.</li>
	<li>Mohon kerjasamanya dan Salam Jumat Klenting.</li>
</ul>

<table class="susunan_perjadin">
	<tr>
		<td>&nbsp;</td>
	</tr>
	<tr>
		<td>Lembar ini tidak perlu dicetak. Terimakasih.</td>
	</tr>
</table>